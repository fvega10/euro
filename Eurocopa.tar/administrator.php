<?php include("php/seguridad_administrator.php"); ?> 
<?php include'header.php'; ?>
<?php
	require("php/conexion.php");
	$ronda = "";
	$username = $_SESSION["userAdministrator"];
	$conexion = mysqli_connect($server, $user, $password, $database);
	if(mysqli_connect_errno()){
		echo "<script type='text/javascript'>alert('La conexion con el servidor ha fallado');</script>";
		exit();	
	}
	mysqli_set_charset($conexion, 'utf8');
	$consulta = "SELECT email, puntuation FROM users order by puntuation desc";
	$resultado = mysqli_query($conexion, $consulta);
	
	if($resultado){
		$cont = 1;
?>
<div class="container-fluid">
	<div class="row singin principal">
		<h3>Usuario: <strong style="color:#7a2121; text-decoration:underline;"><?php echo $username?></strong></h3>
		<div>
		  	<!-- Nav tabs -->
		  	<ul class="nav nav-tabs" role="tablist">
		    	<li role="presentation" class="active"><a href="#home" aria-controls="home" role="tab" data-toggle="tab">TABLA GENERAL</a></li>
		    	<li role="presentation"><a href="#profile" aria-controls="profile" role="tab" data-toggle="tab">RONDA</a></li>
		    	<li role="presentation"><a href="#country" aria-controls="country" role="tab" data-toggle="tab">PAISES</a></li>
		    	<li role="presentation"><a href="#rondas" aria-controls="rondas" role="tab" data-toggle="tab">RONDAS</a></li>
		    	<li role="presentation"><a href="#nueva_ronda" aria-controls="nueva_ronda" role="tab" data-toggle="tab">CREAR NUEVA RONDA</a></li>
		    	<li role="presentation"><a href="#messages" aria-controls="messages" role="tab" data-toggle="tab">PERFIL</a></li>
		  	</ul>
			<br> <br>
		  	<!-- Tab panes -->
		  	<div class="tab-content">
		    	<div role="tabpanel" class="tab-pane active" id="home">
		    		<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
						<div class="panel panel-success">
							<div class="panel-heading">
						    	<h3 class="panel-title"><strong>TABLA GENERAL DE LA QUINIELA - COPA AMERICA</strong></h3>
						  	</div>
						  	<!-- IMPORTANT: IT ALLOWS THE TABLE TO BE RESPONSIVE -->
						  	<div id="source_code_content" class="tab-content">	
								<div id="tbl_container_demo_grid1" class="table-responsive">
									<table id="list" class="table table-bordered table-hover">
										<!-- TABLE HEAD -->
										<thead>
											<tr id="tbl_demo_grid1_tr_0">
												<th class="th-common">
													Posición
												</th>
												<th class="th-common">
													Usuario
												</th>
												<th class="th-common">
													Puntaje
												</th>
											</tr>
										</thead>
										<!-- FINISH TABLE HEAD -->

										<!-- TABLE BODY -->
										<tbody id="table-body" style="cursor:pointer;">
											<?php
												while($row = mysqli_fetch_array($resultado)){
													echo "<tr><td>";
													echo $cont . "</td><td>";
													echo $row['email'] . "</td><td>";
													echo $row['puntuation'] . "</td></tr>";
													$cont++;
												}
											?>
										</tbody>
										<!-- FINISH TABLE BODY -->
									</table>
								</div>
							</div>
							<!-- FINISH TABLE RESPONSIVE -->
						</div>
					</div>
					<!-- FINISH ADDED LIST ARTICLES-->
		    	</div>

		    	<div role="tabpanel" class="tab-pane" id="profile">
		    		<?php
						$consulta = 
	    				"SELECT c.*, r.description, t.description " . 
	    				"FROM country_round c, country r, country t " . 
	    				"WHERE c.id_country_one = r.id AND " . 
	    				"c.id_country_two = t.id AND " . 
	    				"c.id_round = (SELECT id FROM round WHERE is_active = true)";
		    			$resultado = mysqli_query($conexion, $consulta);
						if($resultado){
							$cont = 1;
							while($fila = mysqli_fetch_array($resultado)){
								$consultados = 
								"SELECT r.*, c.description, t.description " . 
								"FROM correct_results r, country c, country t " . 
								"WHERE r.id_country_one = c.id AND ". 
								"r.id_country_two = t.id AND " .
								"r.id_administrator = '$username' AND " .
								"r.id_round = $fila[0] AND " . 
								"r.id_country_one = $fila[1] AND " . 
								"r.id_country_two = $fila[2]";
								
								$resultadodos = mysqli_query($conexion, $consultados);
								if($resultadodos){
									$filados = mysqli_fetch_array($resultadodos);
									if($filados != NULL){
										$ronda = $filados[1];
					?>
										<div class="col-md-4 votation">
							    			<div class="votation-head">
							    				<p>" YA GENERÓ EL VOTO PARA ESTE PARTIDO "</p>
								    			<p><?php echo $filados[7] . " vrs " . $filados[8];?></p>	
							    			</div>
							    			
							    			<form class="form-inline" action="php/votation-modified-administrator.php" method="GET">
							    				<input class="identificators" type="text" name="id_username" value="<?php echo $username; ?>" >
							    				<input class="identificators" type="text" name="id_round" value="<?php echo $filados[1]; ?>" >
											  	<input class="identificators" type="text" name="id_country_one" value="<?php echo $filados[2]; ?>" >
											  	<input class="identificators" type="text" name="id_country_two" value="<?php echo $filados[3]; ?>" >
												<input class="identificators" type="text" name="oldResult_country_one" value="<?php echo $filados[4]; ?>" >
												<input class="identificators" type="text" name="oldResult_country_two" value="<?php echo $filados[5]; ?>" >

											  	<div class="form-group">
												    <div class="input-group">
												      <div class="input-group-addon"><?php echo $filados[7];?></div>
												      <input type="number" name="country_one" class="form-control" placeholder="<?php echo $filados[4]; ?>" value="<?php echo $filados[4]; ?>" id="exampleInputAmount" min="0" max="99">
												    </div>
											  	</div>
											  	<div class="form-group">
												    <div class="input-group">
												      <div class="input-group-addon"><?php echo $filados[8]; ?></div>
												      <input type="number" name="country_two" class="form-control" value="<?php echo $filados[5]; ?>" id="exampleInputAmount" min="0" max="99">
												    </div>
											  	</div>
											  <input type="submit" class="btn btn-primary" value="Modificar" />
											</form>
							    		</div>
								<?php
									}else{ //filados
										$ronda = $fila[0];
								?>
										<div class="col-md-4 votation">
							    			<div class="votation-head">
							    				<p><?php echo $fila[3]; ?></p>
								    			<p><strong>Estadio:</strong> <?php echo $fila[4]; ?></p>
								    			<p><strong>Hora:</strong> <?php echo $fila[5]; ?></p>
							    			</div>
							    			
							    			<form class="form-inline" action="php/votation-administrator.php" method="GET">
							    				<input class="identificators" type="text" name="id_username" value="<?php echo $username; ?>" >
							    				<input class="identificators" type="text" name="id_round" value="<?php echo $fila[0]; ?>" >
											  	<input class="identificators" type="text" name="id_country_one" value="<?php echo $fila[1]; ?>" >
											  	<input class="identificators" type="text" name="id_country_two" value="<?php echo $fila[2]; ?>" >

											  	<div class="form-group">
												    <div class="input-group">
												      <div class="input-group-addon"><?php echo $fila[7]; ?></div>
												      <input type="number" name="country_one" class="form-control" id="exampleInputAmount" min="0" max="99" value="0">
												    </div>
											  	</div>
											  
											  	<div class="form-group">
												    <div class="input-group">
												      <div class="input-group-addon"><?php echo $fila[8]; ?></div>
												      <input type="number" name="country_two" class="form-control" id="exampleInputAmount" min="0" max="99" value="0">
												    </div>
											  	</div>
											  <input type="submit" class="btn btn-primary" value="Votar" />
											</form>
							    		</div>
		    		<?php
					    			}//filados
								}else{//resultadodos
									echo "<script type='text/javascript'>alert('Ocurrió un error inesperado resultados'); </script>";
									break;
								}//resultadodos
							}
						}else{
							echo "<script type='text/javascript'>alert('Ocurrió un error inesperado resultado');</script>;";
						}
	    			?>

		    		<div class="col-md-12">
		    			<div class="row">
		    				<form action="php/close_round.php" method="GET">
		    					<input type="text" name="id_round_close" class="identificators" value="<?php echo $ronda; ?>">
		    					<input type="submit" value="Cerrar jornada">
		    				</form>
		    			</div>
		    		</div>
		    	</div>
				
				<div role="tabpanel" class="tab-pane" id="messages">
		    		<div class="row">
		    			<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
						<div class="panel panel-success">
							<div class="panel-heading">
						    	<h3 class="panel-title"><strong>Datos generales del usuario - COPA AMERICA</strong></h3>
						  	</div>
						  	<!-- IMPORTANT: IT ALLOWS THE TABLE TO BE RESPONSIVE -->
						  	<div id="source_code_content" class="tab-content">	
								<div id="tbl_container_demo_grid1" class="table-responsive">
									<table id="list" class="table table-bordered table-hover">
										<!-- TABLE HEAD -->
										<thead>
											<tr id="tbl_demo_grid1_tr_0">
												<th class="th-common">
													Usuario
												</th>
												<th class="th-common">
													Puntaje
												</th>
											</tr>
										</thead>
										<!-- FINISH TABLE HEAD -->
										<?php
											$consultatres = "SELECT email, puntuation FROM users where email = '$username'";
											$resultadotres = mysqli_query($conexion, $consultatres);

											if($resultadotres){
										?>
										<!-- TABLE BODY -->
										<tbody id="table-body" style="cursor:pointer;">
											<?php
												while($rowtres = mysqli_fetch_array($resultadotres)){
													echo "<tr><td>";
													echo $rowtres['email'] . "</td><td>";
													echo $rowtres['puntuation'] . "</td></tr>";
												}
												
											?>
										</tbody>
										<!-- FINISH TABLE BODY -->
										<?php
											}else{
												echo "<script type='text/javascript'>alert('Ocurrió un error inesperado');</script>";
											}
										?>
									</table>
								</div>
							</div>
							<!-- FINISH TABLE RESPONSIVE -->
						</div>
					</div>
		    			<form action="php/salir.php">
		    				<input type="submit" class="btn btn-danger" value="Cerrar sesión">
		    			</form>
		    		</div>
		    	</div>

		    	<div role="tabpanel" class="tab-pane" id="country">
		    		<div class="col-md-8 col-md-offset-2 other">
		    			<form action="php/country.php" method="GET">
			    			<input type="text" name="pais" placeholder="Digite el nombre del país">
			    			<input type="submit" name="agregar" value="Agregar">
			    		</form>
		    		</div>
		    		<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
						<div class="panel panel-success">
							<div class="panel-heading">
						    	<h3 class="panel-title"><strong>PAISES - COPA AMERICA</strong></h3>
						  	</div>
				    		<!-- IMPORTANT: IT ALLOWS THE TABLE TO BE RESPONSIVE -->
						  	<div id="source_code_content" class="tab-content">	
								<div id="tbl_container_demo_grid1" class="table-responsive">
									<table id="list" class="table table-bordered table-hover">
										<!-- TABLE HEAD -->
										<thead>
											<tr id="tbl_demo_grid1_tr_0">
												<th class="th-common">
													ID
												</th>
												<th class="th-common">
													NOMBRE DEL PAÍS
												</th>
											</tr>
										</thead>
										<!-- FINISH TABLE HEAD -->
										<?php
											$consultatres = "SELECT * FROM country";
											$resultadotres = mysqli_query($conexion, $consultatres);

											if($resultadotres){
										?>
										<!-- TABLE BODY -->
										<tbody id="table-body" style="cursor:pointer;">
											<?php
												while($rowtres = mysqli_fetch_array($resultadotres)){
													echo "<tr><td>";
													echo $rowtres['id'] . "</td><td>";
													echo $rowtres['description'] . "</td></tr>";
												}
												
											?>
										</tbody>
										<!-- FINISH TABLE BODY -->
										<?php
											}else{
												echo "<script type='text/javascript'>alert('Ocurrió un error inesperado');</script>";
											}
										?>
									</table>
								</div>
							</div>
							<!-- FINISH TABLE RESPONSIVE -->
						</div>
					</div>
		    	</div>

		    	<div role="tabpanel" class="tab-pane" id="rondas">
		    		<div class="col-md-8 col-md-offset-2 other">
			    		<form action="php/ronda.php" method="GET">
			    			<input type="text" name="nombre_ronda" placeholder="Digite el nombre de la ronda">
			    			<input type="submit" name="agregar" value="Agregar">
			    		</form>
		    		</div>
		    		<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
						<div class="panel panel-success">
							<div class="panel-heading">
						    	<h3 class="panel-title"><strong>RONDAS - COPA AMERICA</strong></h3>
						  	</div>
				    		<!-- IMPORTANT: IT ALLOWS THE TABLE TO BE RESPONSIVE -->
						  	<div id="source_code_content" class="tab-content">	
								<div id="tbl_container_demo_grid1" class="table-responsive">
									<table id="list" class="table table-bordered table-hover">
										<!-- TABLE HEAD -->
										<thead>
											<tr id="tbl_demo_grid1_tr_0">
												<th class="th-common">
													ID
												</th>
												<th class="th-common">
													NOMBRE DEL PAÍS
												</th>
											</tr>
										</thead>
										<!-- FINISH TABLE HEAD -->
										<?php
											$consultatres = "SELECT * FROM round";
											$resultadotres = mysqli_query($conexion, $consultatres);

											if($resultadotres){
										?>
										<!-- TABLE BODY -->
										<tbody id="table-body" style="cursor:pointer;">
											<?php
												while($rowtres = mysqli_fetch_array($resultadotres)){
													echo "<tr><td>";
													echo $rowtres['id'] . "</td><td>";
													echo $rowtres['description'] . "</td></tr>";
												}
												
											?>
										</tbody>
										<!-- FINISH TABLE BODY -->
										<?php
											}else{
												echo "<script type='text/javascript'>alert('Ocurrió un error inesperado');</script>";
											}
										?>
									</table>
								</div>
							</div>
							<!-- FINISH TABLE RESPONSIVE -->
						</div>
					</div>
		    	</div>

		    	<div role="tabpanel" class="tab-pane" id="nueva_ronda">
		    		<div class="col-md-8 col-md-offset-2 other">
		    			<?php
							$consultatres = "SELECT * FROM round";
							$resultadotres = mysqli_query($conexion, $consultatres);

							if($resultadotres){
						?>
			    		<form action="php/insert_country_round.php" method="GET">
			    			<label for="" style="font-size:20px; text-align:left">RONDA:</label>
			    			<select name="ronda">
				    			<?php 
					    			while($fila = mysqli_fetch_array($resultadotres))
					    			{

				    			?>
			    			
			    				<option value="<?php echo $fila[0]?>"><?php echo $fila[1]?></option>
			    			<?php
									}
								}else{
									echo "<script type='text/javascript'>alert('Ocurrió un error inesperado');</script>";
									break;
								}
			    			?>
			    			</select>
			    			<?php
			    				$consultatres = "SELECT * FROM country";
								$resultadotres = mysqli_query($conexion, $consultatres);

								if($resultadotres){
			    			?>
			    			<label for="" style="font-size:20px; text-align:left">PAISE 1:</label>
			    			<select name="pais1">
			    				<?php 
					    			while($fila = mysqli_fetch_array($resultadotres))
						    			{
				    				?>
				    				<option value="<?php echo $fila[0]?>"><?php echo $fila[1]?></option>
				    				<?php
										}
									}else{
										echo "<script type='text/javascript'>alert('Ocurrió un error inesperado');</script>";
										break;
									}
								?>
			    			</select>
			    			<?php
			    				$consultatres = "SELECT * FROM country";
								$resultadotres = mysqli_query($conexion, $consultatres);

								if($resultadotres){
			    			?>
			    			<label for="" style="font-size:20px; text-align:left">PAISE 2:</label>
			    			<select name="pais2">
			    				<?php 
					    			while($fila = mysqli_fetch_array($resultadotres))
						    			{
				    				?>
				    				<option value="<?php echo $fila[0]?>"><?php echo $fila[1]?></option>
				    				<?php
										}
									}else{
										echo "<script type='text/javascript'>alert('Ocurrió un error inesperado');</script>";
										break;
									}
								?>
			    			</select>
			    			<input type="text" name="descripcion_ronda" placeholder="Descripcion">
			    			<input type="text" name="estadio" placeholder="Estadio">
			    			<input type="text" name="hora" placeholder="Hora">
			    			<input type="submit" name="agregar" value="Agregar">
			    		</form>
		    		</div>

		    		<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
						<div class="panel panel-success">
							<div class="panel-heading">
						    	<h3 class="panel-title"><strong>PAIS-RONDAS - COPA AMERICA</strong></h3>
						  	</div>
				    		<!-- IMPORTANT: IT ALLOWS THE TABLE TO BE RESPONSIVE -->
						  	<div id="source_code_content" class="tab-content">	
								<div id="tbl_container_demo_grid1" class="table-responsive">
									<table id="list" class="table table-bordered table-hover">
										<!-- TABLE HEAD -->
										<thead>
											<tr id="tbl_demo_grid1_tr_0">
												<th class="th-common identificators">
													ID RONDA
												</th>
												<th class="th-common">
													RONDA
												</th>
												<th class="th-common identificators">
													ID COUNTRY 1
												</th>
												<th class="th-common identificators">
													ID COUNTRY 2
												</th>
												<th class="th-common">
													PAIS 1
												</th>
												<th class="th-common">
													PAIS 2
												</th>
												<th class="th-common">
													DESCRIPCION
												</th>
												<th class="th-common">
													ESTADIO
												</th>
												<th class="th-common">
													Hora
												</th>
												<th class="th-common">
													Estado
												</th>
												<th class="th-common">
													Acciones
												</th>
											</tr>
										</thead>
										<!-- FINISH TABLE HEAD -->
										<?php
											$consultatres = "SELECT c.id_round, f.description, c.id_country_one, c.id_country_two, c.description, r.description, c.description, c.stadium, c.hora, c.can_vote FROM country_round c, country r, country t, round f where c.id_round = f.id AND c.id_country_one = r.id AND c.id_country_two = t.id order by id_round";
											$resultadotres = mysqli_query($conexion, $consultatres);

											if($resultadotres){
										?>
										<!-- TABLE BODY -->
										<tbody id="table-body" style="cursor:pointer;">
											<?php
												while($rowtres = mysqli_fetch_array($resultadotres)){
													echo "<tr><td class='identificators'>";
													echo $rowtres[0] . "</td><td>";
													echo $rowtres[1] . "</td><td class='identificators'>";
													echo $rowtres[2] . "</td><td class='identificators'>";
													echo $rowtres[3] . "</td><td>";
													echo $rowtres[4] . "</td><td>";
													echo $rowtres[5] . "</td><td>";
													echo $rowtres[6] . "</td><td>";
													echo $rowtres[7] . "</td><td>";
													echo $rowtres[8] . "</td><td>";
													if($rowtres[9]){
														echo "Abierta</td><td>";
														echo "<form action='php/close_exist_round.php' method='GET'>
															<input class='identificators' type='text' name='roundID' value='" . $rowtres[0] . "'>
															<input class='identificators' type='text' name='country1' value='" . $rowtres[2] . "'>
															<input class='identificators' type='text' name='country2' value='" . $rowtres[3] . "'>
															<input class='btn-change' type='submit' name='close_round' value='Cerrar'>
														</form></td></tr>";
													}else{
														echo "Cerrada</td><td>";
														echo "<form action='php/open_exist_round.php' method='GET'>
															<input class='identificators' type='text' name='roundID' value='" . $rowtres[0] . "'>
															<input class='identificators' type='text' name='country1' value='" . $rowtres[2] . "'>
															<input class='identificators' type='text' name='country2' value='" . $rowtres[3] . "'>
															<input class='btn-change' type='submit' name='close_round' value='Abrir'>
														</form></td></tr>";
													}
													
												}
												
											?>
										</tbody>
										<!-- FINISH TABLE BODY -->
										<?php
											}else{
												echo "<script type='text/javascript'>alert('Ocurrió un error inesperado');</script>";
											}
										?>
									</table>
								</div>
							</div>
							<!-- FINISH TABLE RESPONSIVE -->
						</div>
					</div>
		    	</div>
		  	</div>
		</div>
	</div>
</div>
<?php
	}else{
		echo "<script type='text/javascript'>alert('Ocurrió un error inesperado');</script>";
	}
	mysqli_close($conexion);
	 include'footer.php'; 
?>