	<div class="container-fluid footer">
		<div class="row">
			<h5>Diseño por: <a href="http://innotecweb.com" target="_blank" style="cursor:pointer">Innotecweb</a></h5>
		</div>
	</div>
	<script src="js/jquery.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="js/main.js"></script>
</body>
</html>