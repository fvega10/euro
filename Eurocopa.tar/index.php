<?php include'header.php'; ?>
<?php include'singin.php'; ?>
<?php include'footer.php'; ?>
	
	