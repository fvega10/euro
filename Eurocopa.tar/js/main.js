(function(){

	var principal = document.getElementById("accordion"),
	css = 'a::after{ content: ('-')) }';

	var changeContent = function(){
		
	};

	for (var i = 0; i < principal.childNodes.length; i++) {
		principal.childNodes[i].addEventListener("click", changeContent);
	};
		
}());