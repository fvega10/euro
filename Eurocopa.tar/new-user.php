<?php include'header.php'; ?>

<div class="container-fluid">
	<div class="row singin">
		<img src="logo.png" alt="">
		<form action="php/create-new-user.php" method="POST">
			<input name="email" type="email" placeholder="Digite el correo electrónico" required>
			<input name="userNombre" type="text" placeholder="Digite el nombre de usuario" required>
			<input name="password" type="password" placeholder="Digite la contraseña" required>
			<input name="repassword" type="password" placeholder="Verifique su contraseña" required>
			<input type="submit" value="Crear usuario">
		</form>
	</div>
</div>

<?php include'footer.php'; ?>
	