<?php
	$server = 'localhost';
	$user = 'root';
	$password = '';
	$database = 'eurocopa_db';
	$port = 80;
?>