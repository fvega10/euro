<?php
	require("conexion.php");
	$Round       = $_GET['ronda'];
	$Country1    = $_GET['pais1'];
	$Country2    = $_GET['pais2'];
	$Description = $_GET['descripcion_ronda'];
	$Stadium     = $_GET['estadio'];
	$Hora        = $_GET['hora'];
	$canVote = true;

	$conexion = mysqli_connect($server, $user, $password, $database);
	if(mysqli_connect_errno()){
		echo "<script type='text/javascript'>alert('La conexion con el servidor ha fallado');</script>";
		exit();	
	}

	mysqli_set_charset($conexion, 'utf8');
	mysqli_autocommit($conexion, false);

	$c = "INSERT INTO country_round (id_round, id_country_one, id_country_two, description, stadium, hora, can_vote) 
	VALUES ($Round, $Country1, $Country2, '$Description', '$Stadium', '$Hora', $canVote);";
	
	$r = mysqli_query($conexion, $c);

	if($r){
		$consultados  = "UPDATE round set is_active = true where id = $Round";
		$resultadodos = mysqli_query($conexion, $consultados);

		if($resultadodos){
			mysqli_commit($conexion);
			echo "<script type='text/javascript'>alert('Registro agregado satisfactoriamente'); location.href = '../administrator.php'; </script>";
		}else{
			mysqli_rollback($conexion);
			echo "<script type='text/javascript'>alert(No se pudo agregar el registro: $resultadodos'); location.href = '../administrator.php'; </script>";
		}
	}else{
		mysqli_rollback($conexion);
		echo "<script type='text/javascript'>alert('No se pudo agregar el registro: $r'); location.href = '../administrator.php'; </script>";
	}
	mysqli_close($conexion);
?>