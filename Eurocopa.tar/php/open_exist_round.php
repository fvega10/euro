<?php
	require("conexion.php");
	$IDRound = $_GET["roundID"];
	
	$conexion = mysqli_connect($server, $user, $password, $database);
	if(mysqli_connect_errno()){
		echo "<script type='text/javascript'>alert('La conexion con el servidor ha fallado');</script>";
		exit();	
	}
	mysqli_set_charset($conexion, 'utf8');

	$consulta = 
	"UPDATE country_round set can_vote = true 
	WHERE id_round = $IDRound";

	$resultado = mysqli_query($conexion, $consulta);
	if($resultado){
		$exist = "SELECT count(*) from round where is_active = true";
		$r1 = mysqli_query($conexion, $r1);
		if($r1){
			$row = mysqli_fetch_array($r1);
			if($row[0] === "0"){
				$save = 
				"UPDATE round set is_active = true 
				WHERE id = $IDRound";
				$r2 = mysqli_query($conexion, $r2);
				if($r2){
					echo "<script type='text/javascript'>alert('Votaci\u00F3n abierta satisfactoriamente'); location.href = '../administrator.php'; </script>";
				}else{
					echo "<script type='text/javascript'>alert('No se pudo abierta la votaci\u00F3n'); location.href = '../administrator.php'; </script>";
				}
				
			}else{
				echo "<script type='text/javascript'>alert('Actualmente existe un ronda abierta'); location.href = '../administrator.php'; </script>";
			}
		}else{
			echo "<script type='text/javascript'>alert('No se pudo abierta la votaci\u00F3n'); location.href = '../administrator.php'; </script>";
		}
	}else{
		echo "<script type='text/javascript'>alert('No se pudo abierta la votaci\u00F3n'); location.href = '../administrator.php'; </script>";
	}
	mysqli_close($conexion);
?>