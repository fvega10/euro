<?php 
	include("php/seguridad.php");
	include'header.php'; 
	include'top-bar.php'; 
	require("php/conexion.php");
	$username = $_SESSION["usuarioactual"];
	$usersession = $_SESSION['usuarioname'];
	$conexion = mysqli_connect($server, $user, $password, $database);

	if(mysqli_connect_errno()){
		echo "<script type='text/javascript'>alert('La conexion con el servidor ha fallado');</script>";
		exit();	
	}
	mysqli_set_charset($conexion, 'utf8');
?>

<div class="container-fluid singin">
	<header>
		<nav class="navbar navbar-default">
		  	<div class="container-fluid">
		    	<!-- Brand and toggle get grouped for better mobile display -->
		    	<div class="navbar-header">
		      	<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
		        	<span class="sr-only">Menú</span>
		        	<span class="icon-bar"></span>
		        	<span class="icon-bar"></span>
		        	<span class="icon-bar"></span>
		      	</button>
		      	
		    </div>

		    <!-- Collect the nav links, forms, and other content for toggling -->
		    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
		      	<ul class="nav navbar-nav">
		        	<li role="presentation" class="active"><a href="#allJourny" aria-controls="allJourny" role="tab" data-toggle="tab">Todas las jornadas</a></li>
            		<li role="presentation"><a href="#dayJourny" aria-controls="dayJourny" role="tab" data-toggle="tab">Jornada del día</a></li>
            		<li role="presentation"><a href="#generalTable" aria-controls="generalTable" role="tab" data-toggle="tab"><span class="glyphicon glyphicon-list-alt"></span> Tabla general <span class="sr-only">(current)</span></a></li>
            		<li role="presentation"><a href="#stadistics" aria-controls="stadistics" role="tab" data-toggle="tab">Estadísticas</a></li>
            		<li role="presentation"><a href="#info" aria-controls="info" role="tab" data-toggle="tab">Información general</a></li>
		      </ul>
		    </div><!-- /.navbar-collapse -->
		  </div><!-- /.container-fluid -->
		</nav>
	</header>
	<div class="tab-content">
	   	<div role="tabpanel" class="tab-pane" id="generalTable">
	    	<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
				<div class="panel panel-info">
					<div class="panel-heading">
				    	<h3 class="panel-title"><strong>TABLA GENERAL DE LA QUINIELA - EUROCOPA</strong></h3>
				  	</div>
				  	<!-- IMPORTANT: IT ALLOWS THE TABLE TO BE RESPONSIVE -->
				  	<div id="source_code_content" class="tab-content">	
						<div id="tbl_container_demo_grid1" class="table-responsive">
							<table id="list" class="table table-bordered table-hover">
								<!-- TABLE HEAD -->
								<thead>
									<tr id="tbl_demo_grid1_tr_0">
										<th class="th-common">
											<span class="glyphicon glyphicon-sort-by-order" aria-hidden="true"></span><br />
											Posic.
										</th>
										<th class="th-common">
											<span class="glyphicon glyphicon-user" aria-hidden="true"></span><br />
											Usuario
										</th>
										<th class="th-common">
											<span class="glyphicon glyphicon-tasks" aria-hidden="true"></span><br />
											Puntaje
										</th>
										<th class="th-common">
											<span class="glyphicon glyphicon-new-window" aria-hidden="true"></span><br />
											Acciones
										</th>
									</tr>
								</thead>
								<!-- FINISH TABLE HEAD -->

								<!-- TABLE BODY -->
								<tbody id="table-body" style="cursor:pointer;">
									<?php
										$consulta = "SELECT email, puntuation, user_name FROM users order by puntuation desc";
										$resultado = mysqli_query($conexion, $consulta);
										if($resultado){
											$cont = 1;
											while($fila = mysqli_fetch_array($resultado))
											{
												if($cont === 1){
													echo "<tr class='success'><td>";
												}else{
													echo "<tr><td>";
												}
												echo $cont . "</td><td>";
												echo $fila[2] . "</td><td>";
												echo $fila[1] . "</td><td>";
												echo "<a class='ver-button' href='profile.php?profile=$fila[0]'>Ver perfil</a></td></tr>";
												$cont++;
											}
										}
									?>
								</tbody>
								<!-- FINISH TABLE BODY -->
							</table>
						</div>
					</div>
					<!-- FINISH TABLE RESPONSIVE -->
				</div>
			</div>
		</div>
	 	
	 	<div role="tabpanel" class="tab-pane active" id="allJourny">
	 		<div class="panel-group" id="accordion" role="tablist" aria-multiselectable="true">
			 	<?php
			 		$consulta = "SELECT * from round";
			 		$resultado = mysqli_query($conexion, $consulta);
			 		if($resultado){ //resultado
			 			while($fila = mysqli_fetch_array($resultado)){ //while resultado
				?>
							<div class="panel panel-default">
						   	 	<div class="panel-heading" role="tab" id="<?php echo 'heading' . $fila[0]; ?>">
						      		<h4 class="panel-title">
							        	<a role="button acordeon" data-toggle="collapse" data-parent="#accordion" href="<?php echo '#tab' . $fila[0]; ?>" aria-expanded="true" aria-controls="collapseOne">
							          		<?php echo $fila[1]; ?>
							        	</a>
						      		</h4>
						    	</div>
						    	<div id="<?php echo 'tab' . $fila[0]; ?>" class="panel-collapse collapse" role="tabpanel" aria-labelledby="<?php echo 'heading' . $fila[0]; ?>">
							      	<div class="panel-body">
						        		<?php
						 					$consultaCountryRound = 
						 					"SELECT cr.*, c.description, c2.description 
								    		FROM country_round cr, country c, country c2 
								    		WHERE 
								    		cr.id_round       = $fila[0] AND
								    		cr.id_country_one = c.id AND 
								    		cr.id_country_two = c2.id;";
						 					$resultadoCountryRound = mysqli_query($conexion, $consultaCountryRound);
						 					if($resultadoCountryRound){ //resultadocountryround
						 						while($filaCountryRound = mysqli_fetch_array($resultadoCountryRound)){
													$consultaUser = 
														"SELECT result_country_one, result_country_two 
														FROM results 
														WHERE id_user = '$username' AND 
														id_round = $fila[0] AND 
														id_country_one = $filaCountryRound[1] AND 
														id_country_two = $filaCountryRound[2]";
													$resultadoUser = mysqli_query($conexion, $consultaUser);
													if($resultadoUser){ //resultadoUser
														$filaUser = mysqli_fetch_array($resultadoUser);
														if($filaUser != NULL){ //resultadoUser two
										?>
															<div class="col-md-3 votation">
												    			<div class="votation-head">
												    				<p><strong>Partido:</strong> <?php echo $filaCountryRound[7] . " vrs " . $filaCountryRound[8]; ?></p>
												    				<p><strong>Hora:</strong> <?php echo $filaCountryRound[5]; ?></p>
												    				<p><strong>Estadio:</strong> <?php echo $filaCountryRound[4]; ?></p>		
												    			</div>
												    			
												    			<form class="form-inline" action="php/votation-modified.php" method="GET">
												    				<input class="identificators" type="text" name="id_username" value="<?php echo $username ?>" >
												    				<input class="identificators" type="text" name="id_round" value="<?php echo $filaCountryRound[0];?>" >
																  	<input class="identificators" type="text" name="id_country_one" value="<?php echo $filaCountryRound[1];?>" >
																  	<input class="identificators" type="text" name="id_country_two" value="<?php echo $filaCountryRound[2];?>" >

																  	<div class="form-group">
																	    <div class="input-group">
																	      <div class="input-group-addon"><?php echo $filaCountryRound[7]; ?></div>
													      				<?php
													      					if((boolean)$filaCountryRound[6]){
													      				?>	
															      			<input type="number" name="country_one" class="form-control" value="<?php echo $filaUser[0]; ?>" id="exampleInputAmount" min="0" max="99">
																	    
																	    <?php
													      					}else{
											      						?>
												      						<input type="number" name="country_one" class="form-control" value="<?php echo $filaUser[0]; ?>" id="exampleInputAmount" min="0" max="99" disabled>
													      				<?php
													      					}
													      				?>
																	    </div>
																  	</div>
																  	
																  	<div class="form-group">
																	    <div class="input-group">
																	      <div class="input-group-addon"><?php echo $filaCountryRound[8]; ?></div>
															      		<?php
													      					if((boolean)$filaCountryRound[6]){
													      				?>	
															      			<input type="number" name="country_two" class="form-control" value="<?php echo $filaUser[1]; ?>" id="exampleInputAmount" min="0" max="99">
																	    
																	    <?php
													      					}else{
											      						?>
												      						<input type="number" name="country_two" class="form-control" value="<?php echo $filaUser[1]; ?>" id="exampleInputAmount" min="0" max="99" disabled>
													      				<?php
													      					}
													      				?>
																	    </div>
																  	</div>

																  	<?php
												      					if((boolean)$filaCountryRound[6]){
												      				?>	
														      			<input type="submit" class="btn btn-primary" value="Modificar"></input>
																    
																    <?php
												      					}else{
										      						?>
											      						<p>Votación cerrada</p>
												      				<?php
												      					}
												      				?>
																</form>
												    		</div>
										<?php					//Modificado y cerrado
														}else{
										?>
															<div class="col-md-3 votation">
												    			<div class="votation-head">
												    				<p><strong>Partido:</strong> <?php echo $filaCountryRound[7] . " vrs " . $filaCountryRound[8]; ?></p>
												    				<p><strong>Hora:</strong> <?php echo $filaCountryRound[5]; ?></p>
												    				<p><strong>Estadio:</strong> <?php echo $filaCountryRound[4]; ?></p>		
												    			</div>
												    			
												    			<form class="form-inline" action="php/votation.php" method="GET">
												    				<input class="identificators" type="text" name="id_username" value="<?php echo $username ?>" >
												    				<input class="identificators" type="text" name="id_round" value="<?php echo $filaCountryRound[0];?>" >
																  	<input class="identificators" type="text" name="id_country_one" value="<?php echo $filaCountryRound[1];?>" >
																  	<input class="identificators" type="text" name="id_country_two" value="<?php echo $filaCountryRound[2];?>" >

																  	<div class="form-group">
																	    <div class="input-group">
																	      <div class="input-group-addon"><?php echo $filaCountryRound[7]; ?></div>
															      			<input type="number" name="country_one" class="form-control" value="0" id="exampleInputAmount" min="0" max="99">
																	    </div>
																  	</div>
																  	
																  	<div class="form-group">
																	    <div class="input-group">
																	      <div class="input-group-addon"><?php echo $filaCountryRound[8]; ?></div>
																      		<input type="number" name="country_two" class="form-control" value="0" id="exampleInputAmount" min="0" max="99">
																	    </div>
																  	</div>
													  					<input type="submit" class="btn btn-primary" value="Votar"></input>
																</form>
												    		</div>
										<?php
															//Nuevo
														}
													}//end resultadoUser
												}//end while resultadocountryround
											}else{ //end resultadocountryround
												break;
											}
										?>
							        </div>
						    	</div>
						  	</div>
				
				<?php
 						}//end while resultado
			 		}else{// end resultado
			 			return;
			 		}
			 	?>
			</div>
	 	</div>
		
	    <div role="tabpanel" class="tab-pane" id="dayJourny">
	    	
	    	<?php
	    		$consulta = "SELECT id, description, fecha  FROM round WHERE is_active = true";
	    		$resultado = mysqli_query($conexion, $consulta);
	    		if($resultado){ //resultado
	    			while($fila = mysqli_fetch_array($resultado)){ //while resultado	
			?>    			
		    			<h2 style="background: white;color: #999;padding: 10px;"><?php echo $fila[1]?></h2>
			<?php
						$consultaCountryRound = 
				    		"SELECT cr.*, c.description, c2.description 
				    		FROM country_round cr, country c, country c2 
				    		WHERE 
				    		cr.id_round       = $fila[0] AND
				    		cr.id_country_one = c.id AND 
				    		cr.id_country_two = c2.id;";
			    		$resultadoCountryRound = mysqli_query($conexion, $consultaCountryRound);
			    		if($resultadoCountryRound){ //resultadoCountryRound
			    			while($filaCountryRound = mysqli_fetch_array($resultadoCountryRound)){ //while resultadoCountryRound
			?>
						    	<div class="col-md-3 votation">
					    			<div class="votation-head">
					    				<p><strong>Partido:</strong> <?php echo $filaCountryRound[7] . " vrs " . $filaCountryRound[8]; ?></p>
					    				<p><strong>Hora:</strong> <?php echo $filaCountryRound[5]; ?></p>
					    				<p><strong>Estadio:</strong> <?php echo $filaCountryRound[4]; ?></p>	
					    			</div>
									<?php
										$consultaUser = 
										"SELECT result_country_one, result_country_two
										FROM results 
										WHERE id_user = '$username' AND 
										id_round = $fila[0] AND 
										id_country_one = $filaCountryRound[1] AND 
										id_country_two = $filaCountryRound[2]";
										$resultadoUser = mysqli_query($conexion, $consultaUser);
										if($resultadoUser){ //resultadoUser
											$filaUser = mysqli_fetch_array($resultadoUser);
											if($filaUser[0] != NULL){ //resultadoUser two
									?>
												<form class="form-inline" action="php/votation.php" method="GET">
													<input class="identificators" type="text" name="id_username" value="<?php echo $username ?>" >
								    				<input class="identificators" type="text" name="id_round" value="<?php echo $fila[0];?>" >
												  	<input class="identificators" type="text" name="id_country_one" value="<?php echo $filaCountryRound[2]; ?>" >
												  	<input class="identificators" type="text" name="id_country_two" value="<?php echo $filaCountryRound[3]; ?>" >

												  	<div class="form-group">
													    <div class="input-group">
													      	<div class="input-group-addon">
													      		<?php echo $filaCountryRound[7]; ?>
													      	</div>
							      	<?php
							      							if((boolean)$filaCountryRound[6]){
									?>
							      								<input type="number" name="country_one" class="form-control" value="<?php echo $filaUser[0];?>" id="exampleInputAmount" min="0" max="99" required>
							      	<?php
							      							}else{
							      	?>
							      								<input type="number" name="country_one" class="form-control" value="<?php echo $filaUser[0];?>" id="exampleInputAmount" min="0" max="99" disabled>
							      	<?php
							      							}
							      	?>
													    </div>
												  	</div>
												  	
												  	<div class="form-group">
													    <div class="input-group">
													      	<div class="input-group-addon">
													      		<?php echo $filaCountryRound[8]; ?>
													      	</div>
							      	<?php
							      							if((boolean)$filaCountryRound[6]){
									?>
							      								<input type="number" name="country_two" class="form-control" value="<?php echo $filaUser[1];?>" id="exampleInputAmount" min="0" max="99" required>
							      	<?php
							      							}else{
							      	?>
							      								<input type="number" name="country_two" class="form-control" value="<?php echo $filaUser[1];?>" id="exampleInputAmount" min="0" max="99" disabled>
							      	<?php
							      							}
							      	?>	
													    </div>
												  	</div>
								  	<?php
					      							if((boolean)$filaCountryRound[6]){
									?>
					      								<input type="submit" class="btn btn-primary" value="Modificar"></input>
							      	<?php
					      							}else{
							      	?>
					      								<p><strong>Votación cerrada</strong></p>
							      	<?php
					      							}
							      	?>	
												</form>
									<?php
											}else{ //end resultadoUser two and begin else resultadoUser two
									?>
												<form class="form-inline" action="php/votation.php" method="GET">
													<input class="identificators" type="text" name="id_username" value="<?php echo $username ?>" >
								    				<input class="identificators" type="text" name="id_round" value="<?php echo $fila[0];?>" >
												  	<input class="identificators" type="text" name="id_country_one" value="<?php echo $filaCountryRound[2]; ?>" >
												  	<input class="identificators" type="text" name="id_country_two" value="<?php echo $filaCountryRound[3]; ?>" >

												  	<div class="form-group">
													    <div class="input-group">
													      	<div class="input-group-addon">
													      		<?php echo $filaCountryRound[7]; ?>
													      	</div>
										      				<input type="number" name="country_one" class="form-control" value="0" id="exampleInputAmount" min="0" max="99" required>
													    </div>
												  	</div>
												  	
												  	<div class="form-group">
													    <div class="input-group">
													      	<div class="input-group-addon">
													      		<?php echo $filaCountryRound[8]; ?>
													      	</div>
												      		<input type="number" name="country_two" class="form-control" value="0" id="exampleInputAmount" min="0" max="99" required>
													    </div>
												  	</div>
								  					<input type="submit" class="btn btn-primary" value="Votar"></input>
												</form>
			<?php
											}//end else resultadoUser two
										}else{break;}//resultadoUser
							
			?>
					    		</div>
			<?php
							}//end while resultadoCountryRound
						}else{break;}//end resultadoCountryRound
	    			}//end while resultado
	    		}else{break;}//end resultado
	    	?>	
				    
		</div>

	    <div role="tabpanel" class="tab-pane" id="stadistics">
	    	<?php
	    		$consulta = "SELECT * FROM groups";
	    		$resultado = mysqli_query($conexion, $consulta);
				if($resultado){
					while($fila = mysqli_fetch_array($resultado))
					{
			?>
						<div class="col-md-6">
							<div class="panel panel-info">
								<div class="panel-heading">
							    	<h3 class="panel-title"><strong><?php echo $fila[1]?></strong></h3>
							  	</div>
							  	<!-- IMPORTANT: IT ALLOWS THE TABLE TO BE RESPONSIVE -->
							  	<div id="source_code_content" class="tab-content">	
									<div id="tbl_container_demo_grid1" class="table-responsive">
										<table id="list" class="table table-bordered table-hover">
											<!-- TABLE HEAD -->
											<thead>
												<tr id="tbl_demo_grid1_tr_0">
													<th class="th-common">
														Equipo
													</th>
													<th class="th-common">
														PJ
													</th>
													<th class="th-common">
														G
													</th>
													<th class="th-common">
														E
													</th>
													<th class="th-common">
														P
													</th>
													<th class="th-common">
														GF
													</th>
													<th class="th-common">
														GC
													</th>
													<th class="th-common">
														Ptos.
													</th>
												</tr>
											</thead>
											<!-- FINISH TABLE HEAD -->
											<?php
												$consultaCountryGroup = "SELECT cr.*, c.description, c.name_id
												FROM country_group cr, country c
												WHERE cr.id_country = c.id AND cr.id_groups = $fila[0] order by puntos desc";

												$resultadoCountryGroup = mysqli_query($conexion, $consultaCountryGroup);
												if($resultadoCountryGroup){
											?>
													<tbody id="table-body" style="cursor:pointer;">
											<?php
													while($filaCountryGroup = mysqli_fetch_array($resultadoCountryGroup))
													{
														echo "<tr><td class='alinear'>";
														echo "<span class='icono $filaCountryGroup[10]'></span>" . $filaCountryGroup[9] . "</td><td>";
														echo $filaCountryGroup[2] . "</td><td>";
														echo $filaCountryGroup[3] . "</td><td>";
														echo $filaCountryGroup[4] . "</td><td>";
														echo $filaCountryGroup[5] . "</td><td>";
														echo $filaCountryGroup[6] . "</td><td>";
														echo $filaCountryGroup[7] . "</td><td>";
														echo $filaCountryGroup[8] . "</td></tr>";
													}
											?>
													</tbody> <!-- FINISH TABLE BODY -->
											<?php
												}
											?>
										</table>
									</div>
								</div>
								<!-- FINISH TABLE RESPONSIVE -->
							</div>
			    		</div>
			<?php
					}
				}
			?>

    		<div class="col-md-12">
				<div class="panel panel-info">
					<div class="panel-heading">
				    	<h3 class="panel-title"><strong>Jornadas realizadas - EUROCOPA</strong></h3>
				  	</div>
				  	<!-- IMPORTANT: IT ALLOWS THE TABLE TO BE RESPONSIVE -->
				  	<div id="source_code_content" class="tab-content">	
						<div id="tbl_container_demo_grid1" class="table-responsive">
							<table id="list" class="table table-bordered table-hover">
								<!-- TABLE HEAD -->
								<thead>
									<tr id="tbl_demo_grid1_tr_0">
										<th class="th-common">
											Votación
										</th>
										<th class="th-common">
											Resultado correcto
										</th>
										<th class="th-common">
											Puntos obtenidos
										</th>
									</tr>
								</thead>

							<?php
								$oldResults = 
								"SELECT r.id_round, r.id_country_one, c.description, 
								r.result_country_one, r.correct_result_country_one, 
								r.id_country_two, t.description, r.result_country_two, r.correct_result_country_two
								from results r, country c, country t 
								WHERE r.id_country_one = c.id AND 
								r.id_country_two = t.id AND 
								r.id_user = '$username' AND r.can_modified = false";
								$query = mysqli_query($conexion, $oldResults);
								if($query){
							?>	

								<!-- TABLE BODY -->
								<tbody id="table-body" style="cursor:pointer;">
									<?php
										$total = 0;
										
										while($row = mysqli_fetch_array($query)){
											$totalGeneral = 0;
											if($row[4] != NULL && $row[8] != NULL){
												if($row[3] === $row[4] && $row[7] === $row[8]){
													echo "<tr class='success'><td>";
												}else{
													if( (integer)$row[3] > (integer)$row[7] && (integer)$row[4] > (integer)$row[8] )
													{
														echo "<tr class='warning'><td>";
													}
													else if( (integer)$row[3] < (integer)$row[7] && (integer)$row[4] < (integer)$row[8] )
													{
														echo "<tr class='warning'><td>";
													}
													else if( (integer)$row[3] === (integer)$row[7] && (integer)$row[4] === (integer)$row[8] )
													{
														echo "<tr class='warning'><td>";
													}else{
														echo "<tr class='danger'><td>";
													}
													
												}
												echo $row[2] . ": " . $row[3] . " vrs " . $row[6] . ": " . $row[7] . "</td><td>";
												echo $row[2] . ": " . $row[4] . " vrs " . $row[6] . ": " . $row[8] . "</td><td>";
												if($row[3] === $row[4] && $row[7] === $row[8])
												{
													$totalGeneral = 5;
													$total += 5;
												}else{
													if( (integer)$row[3] > (integer)$row[7] && (integer)$row[4] > (integer)$row[8] )
													{
														$totalGeneral = 2;
														$total += 2;
													}
													if( (integer)$row[3] < (integer)$row[7] && (integer)$row[4] < (integer)$row[8] )
													{
														$totalGeneral = 2;
														$total += 2;
													}
													if( (integer)$row[3] === (integer)$row[7] && (integer)$row[4] === (integer)$row[8] )
													{
														$totalGeneral = 2;
														$total += 2;
													}
												}
												echo $totalGeneral . "</td></tr>";
											}
										}//end while cycle
											echo "<tr><td>";
											echo "</td><td>";
											echo "<strong>PUNTUACIÓN TOTAL:</strong> </td><td>";
											echo "<strong>" . $total . "</strong></td></tr>";
								}else{
									echo "<script type='text/javascript'>alert('Ocurrió un error inesperado');</script>";
								}
									?>
								</tbody>
								<!-- FINISH TABLE BODY -->
							</table>
						</div>
					</div>
					<!-- FINISH TABLE RESPONSIVE -->
				</div>
    		</div>
	    </div>

	    <div role="tabpanel" class="tab-pane" id="info">
	    	<div class="col-md-12">
    			<div class="row">
    				<h2 style="background: white;color: #999;padding: 10px;">¿Como jugar?</h2>
    				<h5 align="justify"><span class="glyphicon glyphicon-hand-right" aria-hidden="true"></span> Las rondas cierran justo antes de iniciar el encuentro.</h5>
    				<h5 align="justify"><span class="glyphicon glyphicon-hand-right" aria-hidden="true"></span> Por acertar el ganador del encuentro además del marcador gana un total de: <strong style="color:yellow">5 PUNTOS</strong></h5>
    				<h5 align="justify"><span class="glyphicon glyphicon-hand-right" aria-hidden="true"></span> Por acertar el ganador del encuentro, gana un total de: <strong style="color:yellow">2 PUNTOS</strong></h5>
    				<h5 align="justify"><span class="glyphicon glyphicon-hand-right" aria-hidden="true"></span> Debe digitar el marcador que usted cree es el correcto y presionar el botón votar, así sucesivamente por cada encuentro</h5>
    				<h5 align="justify"><span class="glyphicon glyphicon-hand-right" aria-hidden="true"></span> Si la ronda no ha sido cerrada usted tendrá la opción de modificar su marcador</h5>
    			</div>
    		</div>
	    </div>
	  </div>

	
</div>
<?php include'footer.php'; ?>