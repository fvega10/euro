<div class="container-fluid">
	<div class="row singin">
		<img src="logo.png" alt="">
		<form action="php/validation-user.php" method="POST">
			<input name="email" type="email" placeholder="Correo electr&oacute;nico" required>
			<input name="password" type="password" placeholder="Contrase&ntilde;a" required>
			<input type="submit" value="Ingresar">
		</form>
		<li><a href="new-user.php">Registrarme</a></li>
	</div>
</div>