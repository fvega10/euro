<div class="container-fluid top">
	<div class="row">
		<ul>
			<li><button type="button" class="btn btn-primary"><span class="glyphicon glyphicon-cog"></span></button></li>
		</ul>
	</div>
</div>